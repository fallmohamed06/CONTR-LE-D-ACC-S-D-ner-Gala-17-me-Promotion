# Contrôle d'Accès — Dîner Gala, 17ème Promotion

Scanner QR pour valider les billets du Dîner Gala (Samedi 3 octobre 2026, 19h, Salle d'Excellence).

## Utilisation

Ouvrez la page publiée (voir lien GitHub Pages ci-dessous) sur le téléphone ou l'ordinateur qui contrôle l'entrée, autorisez l'accès à la caméra, et scannez les QR codes des tickets.

- ✓ **Accès validé** — ticket valide, marqué comme utilisé
- ⚠ **Déjà utilisé** — ticket déjà scanné
- ✕ **Ticket inconnu** — ID non reconnu

Une saisie manuelle de l'ID est disponible si un QR est abîmé.

## Important

La liste des 425 tickets est intégrée directement dans `index.html`. Les validations sont mémorisées **dans le navigateur de l'appareil utilisé** (pas de base partagée) : pour un seul point de contrôle, aucun souci ; avec plusieurs appareils en simultané, chacun a son propre compteur.

## Déploiement (GitHub Pages)

1. `index.html` à la racine du dépôt
2. Settings → Pages → Source : branche `main`, dossier `/ (root)`
3. Le site est servi en HTTPS à `https://fallmohamed06.github.io/CONTR-LE-D-ACC-S-D-ner-Gala-17-me-Promotion/`

## Mise à jour de la liste des tickets

Si les quantités changent, régénérez `index.html` à partir du fichier Excel des tickets (colonne "ID Ticket") et remplacez le fichier dans le dépôt.
